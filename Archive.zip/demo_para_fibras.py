import numpy as np
from matplotlib import cm
import matplotlib.pyplot as plt
plt.ion()
# imports que podrian estar en este mismo archivo!
from generarD import generarD
from fouriercont2D_comp import fouriercont2D_comp
# creo que esto no hace falta!
from imagetodephasemap1D import imagestodphasemap1D

# Lx y Ly eran 315
# Lx, Ly = 150, 150 
# lambdaa=8


# Z=np.random.normal(1200,200,25)
# B=Lx*(np.random.rand(25)*0.9+0.05)
# C=Ly*(np.random.rand(25)*0.9+0.05)
# signo=np.sign(2*np.random.rand(25)-1)
# iphi=np.zeros(np.shape(x))

# for i in range (0,25):
#     iphi=iphi+signo[i]*np.exp((-(x-C[i])**2-(y-B[i])**2)/Z[i])

# fig = plt.figure()
# ax = fig.gca(projection='3d')
# surf = ax.plot_surface(x, y, iphi, cmap=cm.coolwarm,linewidth=0, antialiased=False)
# plt.title('Fase Original')
 # plt.show()

# R=0.*np.random.rand(1)/10

# refo=np.cos(2*np.pi/lambdaa*x) + R*(-1+2*np.random.rand(Lx,Ly))
# defo=np.cos(2*np.pi/lambdaa*x+iphi) + R*(-1+2*np.random.rand(Lx,Ly))

# f, (ax1, ax2) = plt.subplots(1, 2)
# ax1.imshow(refo)
# ax1.set_title('Referencia')
# ax2.imshow(defo)
# ax2.set_title('Deformada')
# plt.show()


# s = 0.9 # valor original
# ns = 0.2 #valor original
# rphi = imagestodphasemap1D(defo,refo,s,ns)

# fig = plt.figure()
# ax = fig.gca(projection='3d')
# surf = ax.plot_surface(x, y, rphi, cmap=cm.coolwarm,linewidth=0, antialiased=False)
# plt.title('Fase Recuperada sin agujero')
# plt.show()

# porcion=[0,315];

# maskoutholeaux=np.ones(np.shape(refo[porcion[0]:porcion[1],porcion[0]:porcion[1]]));


# era a=40, rad=8
# rad=10.
# a=200.
# aux=0.
# xx=np.arange(porcion[0]+2.5*rad,porcion[1]-1.5*rad,a)
# yy=np.arange(porcion[0]+2.5*rad,porcion[1]-1.5*rad,a)

# for ll in range (0,len(yy)):
#     for kk in range (0,len(xx)):
#         maskoutholeaux[np.sqrt((x[porcion[0]:porcion[1],porcion[0]:porcion[1]]-xx[kk])**2+(y[porcion[0]:porcion[1],porcion[0]:porcion[1]]-yy[ll])**2)<rad]=0
# maskouthole=np.ones(np.shape(refo))
# maskouthole[porcion[0]:porcion[1],porcion[0]:porcion[1]]=maskoutholeaux

# RNAN=np.sum(maskouthole==0)/((porcion[1]-porcion[0])**2-np.sum(maskouthole==0))

# un solo agujero centrado
# radx = 3 
# rady = 40
# # maskouthole=np.ones(np.shape(refo))
# maskouthole = ((x-int(Lx/2))**2/radx**2 + (y-int(Ly/2))**2/rady**2 >= 1)

# Aplicamos las mascaras
# ref0 = refo*maskouthole;
# def0 = defo*maskouthole;

# plt.close('all')
# plt.figure()
# plt.imshow(def0)

# rphiWH = imagestodphasemap1D(def0,ref0,s,ns);

# rphiWH[maskouthole==0] = np.nan;

#  Fourier Continuation of one of the holes.

# d1,d2 = np.shape(def_hole);

# ref_hole=refo.copy()
# def_hole=defo.copy()

# ref_hole[maskouthole== 0]=np.nan
# def_hole[maskouthole== 0]=np.nan

# cargamos archivo de medicion -------------------------------------------
imn = np.load('imn.npy')

imn = imn[250:425, 200:375]
def_hole = imn
# Lx, Ly = np.shape(def_hole)
Lx, Ly = np.shape(def_hole)
# Ly, Lx = np.shape(def_hole)
d1,d2 = np.shape(def_hole)
# x,y=np.meshgrid(np.arange(Lx),np.arange(Ly))

# plt.figure()
# plt.imshow(def_hole)

# print('paso carga')
# stop




# Determinacion de Mx y My

k=np.arange(0,(Lx)/2)/(Lx)
kxs=np.zeros(Lx)

for ii in range (0,Lx):
    fftdefx=np.fft.fft(def_hole[ii,:])
    P2=np.abs(fftdefx/Lx)
    # forzamos cero en componente DC
    P2[0] = 0
    P1=P2[0:int(np.floor(Lx/2+1))]
    P1[1:-1]=2*P1[1:-1]
    imax=np.argmax(np.abs(P1))
    kxs[ii]=k[imax]

kx=np.sum(kxs[kxs!=0])/len(kxs[kxs!=0])
bx0=(.8/kx+d2)/d1
by0=(.8/kx+d2)/d1
Mx = int(np.floor(bx0*Lx*2*kx))
Mx *= 2

print('Mx=' + str(Mx))

k=np.arange(0,(Ly)/2)/(Ly)
kys=np.zeros(Ly)

for jj in range (0,Ly):
    fftdefy=np.fft.fft(def_hole[:,jj])
    P2=np.abs(fftdefy/Ly)
    P1=P2[0:int(np.floor(Ly/2+1))]
    P1[1:-1]=2*P1[1:-1]
    imax=np.argmax(np.abs(P1))
    imax2=imax
    while P1[imax2]>P1[imax]/10:
            imax2=imax2+1
    kys[ii]=k[imax2]

ky=np.max(kys[kys!=0])

My = int(np.floor(by0*Ly*ky)+5)
My *= 2

print('My=' + str(My))

if Mx*My>100*10:
    print('****************************')
    print('Matriz para SVD grande, continuar?')
    print(Mx)
    print(My)
    print('****************************')
    lo=input("1 para continuar, cualquier otra tecla para abortar: ")
    if lo!=1:
        import sys
        sys.exit("Abortado")


D, U ,S, V=generarD(def_hole,Mx,My,bx0,by0)
print('Listo SVD')
# ref_hole_FC=fouriercont2D_comp(def_hole,Mx,My,bx0,by0,D,U,S,V)
# print('Listo Refo')
def_hole_FC=fouriercont2D_comp(def_hole,Mx,My,bx0,by0,D,U,S,V)
print('Listo Defo')
# toc()

# print(np.shape(def_hole_FC))

plt.figure()
plt.imshow(def_hole_FC[:,0:150])
plt.colorbar()

plt.figure()
plt.imshow(def_hole[:,0:150])
plt.colorbar()

stop

